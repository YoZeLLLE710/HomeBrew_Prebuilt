## Windows
----
#### Formatting the SD Card
1. Run _GUIFormat_ with Administrator permissions
2. Select your drive letter.
3. For your allocation size unit, set it to 32768.
4. If the checkbox for _Quick Format_ has a check inside, tick it off.
5. Start the format process.

#### Checking for Errors
1. Go to the properties window of your SD card.
    ```Windows Explorer -> This PC -> Right click your SD card -> Properties.```
3. In the tools tab, Select _Check Now_.
4. Check both _Automatically fix file system errors_ and _Scan for and attempt recovery of bad sectors_.
5. Start the checking process.
This will scan the SD card and correct any errors it finds.

#### Checking SDCard Read/Write
1. Run ```h2testw.exe``` _in h2testw\_1.4_ folder
2. Select which language you’d like to see h2testw in
3. Set your SD card’s drive letter as your target
4. Ensure _all available space_ is selected
5. Click _Write + Verify_
When that's done, your SDcard is ready and you can simply copy paste the contents of _Put in SDCard_ into your sd card.

## Launching the Exploit
1. Boot your Nintendo DSi and launch the DSi Camera application.(please make sure your camera works)
2. With your SD card inserted into your console, select the SD Card icon on the top right.
    * If you recieve a message saying your SD card isn’t inserted, please use another SD card.
3. Select your SD card’s camera album.
4. If you copied Memory Pit correctly, the system should flash magenta.

Boom! Now, you are in TWiLight Menu++, here you can navigate inside your sd card and all of its files. You can now put .nds roms into the sdcard via your pc and play it on your Nintendo DSi!
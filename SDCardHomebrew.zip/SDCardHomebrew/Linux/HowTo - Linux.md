## Linux
#### Formatting the SD Card
1. Type in ```sudo cfdisk /dev/(device mount point from above).```
2. On each partition, hit Delete.
3. Create a new Primary partition that covers the size of your entire SD card.
4. This will create a new partition with the linux filetype.
5. Select _type_ and take a look at the menu.
6. Find _W95 FAT32_ and take note of the code on the left side of that text.
7. Press enter, then select write and hit enter and then type yes. 
8. Hit Quit.

#### Using F3Permalink
1. Download and extract the F3 archive anywhere on your computer.
2. Launch the terminal in the F3 directory.
3. Run make to compile F3 (It is already done for you)
4. With your SD card inserted and mounted, run ```./f3write <your sd card mount point>```.
5. Wait until the process is complete.
6. Run ```./f3read your sd <card mount point>.```
7. Wait until the process is complete.
When that's done, your SDcard is ready and you can simply copy paste the contents of _Put in SDCard_ into your sd card.

## Launching the Exploit
1. Boot your Nintendo DSi and launch the DSi Camera application.(please make sure your camera works)
2. With your SD card inserted into your console, select the SD Card icon on the top right. 
    * If you recieve a message saying your SD card isn’t inserted, please use another SD card.
3. Select your SD card’s camera album.
4. If you copied Memory Pit correctly, the system should flash magenta.

Boom! Now, you are in TWiLight Menu++, here you can navigate inside your sd card and all of its files. You can now put .nds roms into the sdcard via your pc and play it on your Nintendo DSi!